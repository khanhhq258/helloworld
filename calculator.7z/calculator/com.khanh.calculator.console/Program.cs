﻿using System;
using com.khanh.calculator.operation;

namespace com.khanh.calculator.console
{
    class Program
    {
        static void Main(string[] args)
        {
            string command="";
            
            while (command != "exit") {
                double num1 = 0;
                double num2 = 0;
                Console.Write("Input first number: ");
                string num1String = Console.ReadLine();
               
                try
                {
                    num1 = Convert.ToDouble(num1String);

                }
                catch (FormatException ex)
                {
                    Console.WriteLine(ex.Message);
                    goto FinishOperation;
                }

                Console.WriteLine();
                Console.Write("Input second number: ");
                string num2String = Console.ReadLine();
                try
                {
                    num2 = Convert.ToDouble(num2String);

                }
                catch (FormatException ex)
                {
                    Console.WriteLine(ex.Message);
                    goto FinishOperation;
                }

                Console.WriteLine();
                Console.Write("Input operation '+, -, *, /': ");
                string ope = Console.ReadLine();

                Console.WriteLine("Result: "+ CalculatorOperation.OperationManager(ope,num1,num2));
                FinishOperation:
                Console.WriteLine("Press exit to end, any thing to continue: ");
                command=Console.ReadLine();
            }
        

        
        }

    
    }
}
