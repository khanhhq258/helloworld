﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.khanh.calculator.operation
{
    public class CalculatorOperation
    {
        public static double AddTowNumber(double num1, double num2)
        {
            return num1 + num2;
        }

        public static double SubtractTowNumber(double num1, double num2)
        {
            return num1 - num2;
        }
        public static double DevideTwoNumber(double num1, double num2)
        {
            double result=0;
            
            
                if (num2 != 0) {
                    result = (double)num1 / num2;
                    
                }
                else
                {
                    throw (new CalculatorException("Can not devide by zero number"));
                }
            
           
            return result;
        }

        public static double MultipleTowNumber(double num1, double num2)
        {
            return num1 * num2;
        }

        public static double OperationManager(String ope, double num1, double num2 ) {
            double result = 0;
            switch(ope){
                case "/":
                    result=DevideTwoNumber(num1, num2);
                    break;
                case "+":
                    result = AddTowNumber(num1, num2);
                    break;
                case "-":
                    result = SubtractTowNumber(num1, num2);
                    break;
                case "*":
                    result = MultipleTowNumber(num1, num2);
                    break;
                default:
                    Console.Write("This is not operator");
                    break;
            }
            return result;
        }
    }

}
